﻿namespace Company.Services
{
    public class Class1
    {

    }
}